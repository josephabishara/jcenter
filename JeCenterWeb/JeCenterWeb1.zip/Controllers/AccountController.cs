﻿using JeCenterWeb.Data;
using JeCenterWeb.Models.ViewModel;
using JeCenterWeb.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;

namespace JeCenterWeb.Controllers;

[AllowAnonymous]
public class AccountController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly ILogger<AccountController> _logger;
    public const string SessionKeyName = "_Name";
    public const string SessionKeyPhase = "_phase";
    public const string SessionKeyPhysicalyear = "_physicalyear";
    public const string SessionKeyId = "_id";
    public AccountController(ApplicationDbContext context,
      UserManager<ApplicationUser> userManager,
      SignInManager<ApplicationUser> signInManager,
      ILogger<AccountController> logger)
    {
        _context = context;
        _userManager = userManager;
        _signInManager = signInManager;
        _logger = logger;
    }



    [AllowAnonymous]
    [Route("Login")]
    [HttpGet]
    public IActionResult Login()
    {
        bool isAuthenticated = User.Identity.IsAuthenticated;
        if (isAuthenticated == true)
        {
            return RedirectToAction("Index", "Home");
        }
        return View();
    }

    [HttpPost]
    [Route("Login")]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        //if (ModelState.IsValid)
        //{

        var result = await _signInManager.PasswordSignInAsync(model.Mobile, model.Password, true,false);
        if (result.Succeeded)
        {

            string returnUrl = HttpContext.Request.Query["returnUrl"];
            if (!String.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);
            else
                return RedirectToAction("signin", "Account");

        }
        ModelState.AddModelError(string.Empty, "invalid Email or Password !");
        //}
        return View(model);
    }

    public async Task<IActionResult> signin()
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        ApplicationUser user = await _userManager.FindByIdAsync(userId);
        if (string.IsNullOrEmpty(HttpContext.Session.GetString(SessionKeyName)))
        {
            HttpContext.Session.SetString(SessionKeyName, user.FullName);
            HttpContext.Session.SetInt32(SessionKeyId, user.Id);
            //HttpContext.Session.SetInt32(SessionKeyPhase, user.PhaseId);
        }
        string username = HttpContext.Session.GetString(SessionKeyName);

        if (user.UserTypeId < 5)
        {
            return RedirectToRoute(new { area = "scp", controller = "Dashboard", action = "Index" });
        }
        else if (user.UserTypeId == 7)
        {
            //if (string.IsNullOrEmpty(HttpContext.Session.GetString(SessionKeyPhase)))
            //{
            //    HttpContext.Session.SetInt32(SessionKeyPhase, user.PhaseId);
            //}
            var studentapp = await _context.StudentApplications
                .Where(s => s.StudentId == user.Id)
                .OrderByDescending(s => s.ApplicationId).FirstOrDefaultAsync();
            if (studentapp != null)
            {
                HttpContext.Session.SetInt32(SessionKeyPhase, studentapp.PhaseId);
                HttpContext.Session.SetInt32(SessionKeyPhysicalyear, studentapp.PhysicalyearId);
                return RedirectToRoute(new { controller = "Dashboard", action = "Index", area = "learning" });
            }
            else
            { 
                HttpContext.Session.SetInt32(SessionKeyPhase, 0);
                HttpContext.Session.SetInt32(SessionKeyPhysicalyear, 0);
                // SessionKeyPhysicalyear
                return RedirectToRoute(new { controller = "Applications", action = "Index", area = "learning" });
            }
           
        }

        return RedirectToAction("Index", "Home");
    }

    [HttpGet]
    [Route("Register")]
    [AllowAnonymous]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    [Route("Register")]
    [AllowAnonymous]
    public async Task<IActionResult> Register([Bind("FristName,SecondName,LastName,FamilyName,Mobile,Password,ConfirmPassword,Address,NationalID,Birthdate,School,GenderId,PhaseId,ParentJob,ParentMobile")] RegisterViewModel registerViewModel)
    {
        string imgurl = "images/Students/default.jpg";
        ViewData["PhaseId"] = new SelectList(_context.CPhases.Where(p => p.Parent > 0 && p.Active == true), "PhaseId", "PhaseName");
      
        if (ModelState.IsValid)
        {
            FinancialAccount financialAccount = new FinancialAccount
            {
                AccountName = registerViewModel.FristName + " " + registerViewModel.SecondName + " " + registerViewModel.LastName + " " + registerViewModel.FamilyName,
                AccountTypeId = 7,
                // UserId = user.Id,
            };

            _context.Add(financialAccount);
            await _context.SaveChangesAsync();

            int FinancialAccountId = financialAccount.FinancialAccountId;

            var user = new ApplicationUser();

            user.Email = "e" + registerViewModel.Mobile + "@elra3ycenter.com" ;
            user.UserName = registerViewModel.Mobile;
            user.Mobile = registerViewModel.Mobile;
            user.FullName = registerViewModel.FristName + " " + registerViewModel.SecondName + " " + registerViewModel.LastName + " " + registerViewModel.FamilyName;
            user.FristName = registerViewModel.FristName;
            user.SecondName = registerViewModel.SecondName;
            user.FamilyName = registerViewModel.FamilyName;
            user.LastName = registerViewModel.LastName;
            user.Address = registerViewModel.Address;
            user.NationalID = registerViewModel.NationalID;
            user.Birthdate = registerViewModel.Birthdate;
            user.School = registerViewModel.School;

            user.AccountID = FinancialAccountId;
            user.ParentJob = registerViewModel.ParentJob;
            user.DepartmentId = 0;
            user.UserTypeId = 7;
            user.ParentMobile = registerViewModel.ParentMobile;
            user.Pwd = registerViewModel.Password;
            user.imgurl = imgurl;
            user.Active = true;

            var result = await _userManager.CreateAsync(user, registerViewModel.Password);
            if (result.Succeeded)
            {
                await _signInManager.SignInAsync(user, false);

                List<string> role = new List<string>();
                role.Add("Student");
                await _userManager.AddToRolesAsync(user, role);

                return RedirectToAction("logout");
            }
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }
        return View();
    }


    [HttpGet]
    [Route("Logout")]
    public async Task<IActionResult> logout()
    {
        await _signInManager.SignOutAsync();
        return RedirectToAction("Login", "Account");
    }



 
   

}
