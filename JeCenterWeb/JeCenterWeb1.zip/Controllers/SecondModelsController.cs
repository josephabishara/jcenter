﻿using JeCenterWeb.Data;
using JeCenterWeb.Models.ViewModel;
using JeCenterWeb.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace JeCenterWeb.Controllers;

[AllowAnonymous]
public class SecondModelsController : Controller
{
    private readonly SecondDbContext _secondcontext;
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;
    public SecondModelsController(SecondDbContext secondcontext,
        ApplicationDbContext context,
        UserManager<ApplicationUser> userManager,
        SignInManager<ApplicationUser> signInManager)
    {
        _secondcontext = secondcontext;
        _context = context;
        _userManager = userManager;
        _signInManager = signInManager;
    }
    public async Task<IActionResult> Index()
    {
        var model = await _secondcontext.Teachers.ToListAsync();
        return View(model);
    }
    //   user.ParentId = item.TeacherID;
    //  user.ParentMobile = item.Account.ToString();
    public async Task<IActionResult> CreateAdmins()
    {
        string imgurl = "images/Teachers/default.png";
        var model = await _secondcontext.Teachers.ToListAsync();

        foreach (var item in model)
        {
            FinancialAccount financialAccount = new FinancialAccount
            {
                AccountName = item.TeacherName,
                AccountTypeId = 5,
                // UserId = user.Id,
            };
            _context.Add(financialAccount);
            await _context.SaveChangesAsync();
            int FinancialAccountId = financialAccount.FinancialAccountId;
            var user = new ApplicationUser();

            user.Email = item.TeacherEmail;
            user.UserName = item.TeacherEmail;
            user.FullName = item.TeacherName;
            user.Mobile = item.Mobile;
            user.ParentId = item.TeacherID;
            user.ParentMobile = item.Account.ToString();
            user.AccountID = FinancialAccountId;
            user.DepartmentId = 5;
            user.UserTypeId = 5;
            user.Pwd = item.TeacherPassword;
            user.imgurl = imgurl;
            user.Active = true;

            var result = await _userManager.CreateAsync(user, item.TeacherPassword);
            if (result.Succeeded)
            {
                List<string> role = new List<string>();
                role.Add("Teacher");
                await _userManager.AddToRolesAsync(user, role);
            }
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }
        return RedirectToAction("Index", "SecondModels");
    }



}
