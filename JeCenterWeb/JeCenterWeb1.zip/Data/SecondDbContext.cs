﻿using Microsoft.EntityFrameworkCore;
using JeCenterWeb.Models.Second;


namespace JeCenterWeb.Data
{
    public class SecondDbContext : DbContext
    {
        public SecondDbContext(DbContextOptions options)
       : base(options)
        {
        }

        public DbSet<AdminUsers> AdminUsers { get; set; }
        public DbSet<Clint> Clint { get; set; }
        public DbSet<Users> Users { get; set; }

        public DbSet<Teachers> Teachers { get; set; }

    }
}
