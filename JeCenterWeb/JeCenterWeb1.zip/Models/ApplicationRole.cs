﻿using Microsoft.AspNetCore.Identity;

namespace JeCenterWeb.Models
{
    public class ApplicationRole : IdentityRole<int>
    {
    }
}
