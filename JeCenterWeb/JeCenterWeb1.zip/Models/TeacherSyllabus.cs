﻿using System.ComponentModel.DataAnnotations;

namespace JeCenterWeb.Models
{
    public class TeacherSyllabus : MasterModel
    {
        [Key]
        public int TeacherSyllabusId { get; set; }
        public int TeacherId { get; set; }
        [Display(Name = " اسم المادة / المنهج ")]
        public int SyllabusID { get; set; }
        [Display(Name = " المرحلة ")]
        public int PhaseId { get; set; }
        [Display(Name = " اسم المادة / المنهج ")]
        public string SyllabusName { get; set; }
    }
}
