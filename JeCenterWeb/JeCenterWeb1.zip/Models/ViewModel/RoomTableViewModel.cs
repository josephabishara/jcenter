﻿namespace JeCenterWeb.Models.ViewModel
{
    public class RoomTableViewModel
    {
        public CRooms CRoom { get; set; }
        public IEnumerable<CGroups>? CGrouplist { get; set; }
    }
}
