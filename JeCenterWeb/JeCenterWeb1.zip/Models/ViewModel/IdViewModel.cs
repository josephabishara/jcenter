﻿namespace JeCenterWeb.Models.ViewModel
{
    public class IdViewModel
    {
        public int id { get; set; }
    }
}
