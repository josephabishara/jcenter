﻿namespace JeCenterWeb.Models.ViewModel
{
    public class CBranchViewModel
    {
        public CBranch? CBranch { get; set; }
        public IEnumerable<CRooms>? CRooms { get; set; }
    }
}
