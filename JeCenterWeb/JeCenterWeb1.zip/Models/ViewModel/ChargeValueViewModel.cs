﻿namespace JeCenterWeb.Models.ViewModel
{
    public class ChargeValueViewModel
    {
        public int id { get; set; }
        public string Value { get; set; }
    }
}
