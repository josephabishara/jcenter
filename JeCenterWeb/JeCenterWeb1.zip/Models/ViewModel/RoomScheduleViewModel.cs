﻿namespace JeCenterWeb.Models.ViewModel
{
    public class RoomScheduleViewModel
    {
        public CRooms Room { get; set; }
        public IEnumerable<RoomGroupReviewsExamsScheduleViewModel>? RoomGroupReviewsExamsScheduleViewModel { get; set; }


    }
}
