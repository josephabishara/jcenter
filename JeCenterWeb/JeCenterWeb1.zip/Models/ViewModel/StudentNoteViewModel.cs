﻿namespace JeCenterWeb.Models.ViewModel
{
    public class StudentNoteViewModel
    {
        public int id { get; set; }
        public string Note { get; set; }
    }
}
