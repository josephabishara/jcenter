﻿namespace JeCenterWeb.Models.ViewModel
{
    public class DateViewModel
    {
        public DateTime date { get; set; }
    }
}
