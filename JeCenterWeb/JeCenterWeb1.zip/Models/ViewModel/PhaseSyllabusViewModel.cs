﻿namespace JeCenterWeb.Models.ViewModel
{
    public class PhaseSyllabusViewModel
    {
        public CPhases? CPhases { get; set; }
        public IEnumerable<CSyllabus>? CSyllabus { get; set; }
    }
}
