﻿namespace JeCenterWeb.Models.ViewModel
{
    public class IdDateViewModel
    {
        public int id { get; set; }
        public DateTime date { get; set; }
    }
}
