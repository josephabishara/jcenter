﻿using System.ComponentModel.DataAnnotations;

namespace JeCenterWeb.Models.ViewModel
{
    public class RoomGroupReviewsExamsScheduleViewModel
    {
        [Key]
        public int Id { get; set; }
        public int RoomId { get; set; }
        public string Titel { get; set; }
        public TimeSpan SessionStart { get; set; }
        public TimeSpan SessionEnd { get; set; }
        public DateTime Date { get; set; }
        public int TypeId { get; set; }
    }
}
