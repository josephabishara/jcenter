﻿namespace JeCenterWeb.Models.ViewModel
{
    public class TeachersGroupsViewModel
    {
        public int id { get; set; }
        public string? TeacherName { get; set; }
        public string? imgurl { get; set; }
        public int CountOfGroups { get; set; }
        public int SyllabusID { get; set; }
    }
}
