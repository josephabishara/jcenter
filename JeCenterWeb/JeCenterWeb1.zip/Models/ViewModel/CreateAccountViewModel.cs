﻿namespace JeCenterWeb.Models.ViewModel
{
    public class CreateAccountViewModel
    {
        public string AccountName { get; set; }
    }
}
