﻿namespace JeCenterWeb.Models.ViewModel
{
    public class CreateStudentApplicationViewModel
    {
        //   public int BranchId { get; set; }
        public int StudentId { get; set; }
        public int PhysicalyearId { get; set; }
        public int PhaseId { get; set; }
    }
}
