﻿namespace JeCenterWeb.Models.ViewModel
{
    public class IdWordDateViewModel
    {
        public int id { get; set; }
        public string word { get; set; }
        public DateTime date { get; set; }
    }
}
