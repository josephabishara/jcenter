﻿namespace JeCenterWeb.Models.ViewModel
{
    public class SearchByWordViewModel
    {
        public string word { get; set; }
    }
}
