﻿namespace JeCenterWeb.Models.ViewModel
{
    public class IdWordViewModel
    {
        public int id { get; set; }
        public string word { get; set; }
    }
}
