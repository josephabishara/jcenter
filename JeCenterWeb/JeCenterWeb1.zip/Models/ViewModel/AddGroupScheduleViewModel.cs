﻿namespace JeCenterWeb.Models.ViewModel
{
    public class AddGroupScheduleViewModel
    {
        public IEnumerable<CGroupSchedule>? CGroupSchedule { get; set; }
        public IEnumerable<ReviewsSchedule>? ReviewsSchedule { get; set; }
    }
}
