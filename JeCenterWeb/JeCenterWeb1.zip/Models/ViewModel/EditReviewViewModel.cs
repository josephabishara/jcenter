﻿using System.ComponentModel.DataAnnotations;

namespace JeCenterWeb.Models.ViewModel
{
    public class EditReviewViewModel
    {
        public int ReviewId { get; set; }
        [Display(Name = " من ")]
        public TimeSpan SessionStart { get; set; }
        [Display(Name = " الى ")]
        public TimeSpan SessionEnd { get; set; }
        [Display(Name = " ق المدرس ")]
        public int TeacherFee { get; set; }
        [Display(Name = " ق المركز ")]
        public int CenterFee { get; set; }
        [Display(Name = " خ السنتر ")]
        public int ServiceFee { get; set; }
        [Display(Name = " القاعة ")]
        public int RoomId { get; set; }
        public DateTime date { get; set; }
        public int Type { get; set; }
    }
}
